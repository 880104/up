#ifndef _NAS782X_SPL_H
#define _NAS782X_SPL_H

#include <asm/arch/cpu.h>

#endif /* _NAS782X_SPL_H */
